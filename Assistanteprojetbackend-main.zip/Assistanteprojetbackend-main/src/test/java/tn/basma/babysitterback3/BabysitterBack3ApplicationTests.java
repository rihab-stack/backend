package tn.basma.babysitterback3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BabysitterBack3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
