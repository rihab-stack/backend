package tn.basma.babysitterback3.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import tn.basma.babysitterback3.entites.Services;

public interface ServiceAssistanteRepository extends JpaRepository<Services,Long> {


}
