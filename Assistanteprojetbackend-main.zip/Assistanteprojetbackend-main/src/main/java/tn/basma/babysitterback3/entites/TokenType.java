package tn.basma.babysitterback3.entites;

public enum TokenType {
    BEARER
}