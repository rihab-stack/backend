package tn.basma.babysitterback3.entites;

public enum Role {
        ADMIN,Parent,Assistante

    }