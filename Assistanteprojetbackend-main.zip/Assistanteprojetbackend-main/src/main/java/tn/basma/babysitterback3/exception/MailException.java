package tn.basma.babysitterback3.exception;

public class MailException extends org.springframework.mail.MailException {
    public MailException(String message) {
        super(message);
    }
}