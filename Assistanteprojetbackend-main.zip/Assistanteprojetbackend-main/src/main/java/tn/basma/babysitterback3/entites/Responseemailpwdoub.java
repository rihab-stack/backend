package tn.basma.babysitterback3.entites;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class Responseemailpwdoub {
    private String messageResponse;

}