package tn.basma.babysitterback3.entites;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class Verifyotppwdoublier {
    private String email;
    private Integer otp;

}