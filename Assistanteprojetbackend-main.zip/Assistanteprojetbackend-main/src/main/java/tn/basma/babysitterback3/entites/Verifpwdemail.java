package tn.basma.babysitterback3.entites;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Verifpwdemail {
    private String email;

}